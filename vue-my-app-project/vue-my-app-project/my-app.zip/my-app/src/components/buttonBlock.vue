<template>
  <v-container><br>
    <div class="buttonBlock">
    <v-row
    align="center"
    justify="space-around"
    >
    <v-btn
      depressed
      color="secondary"
    >
      EXPLORE MEETUPS
    </v-btn>
    <v-btn
      depressed
      color="primary"
    >
      ORGANIZE A MEETUP
    </v-btn>
    </v-row>
    </div>
    <br>
    <h2 class="text-center">Featured Meetups</h2>
  </v-container>
  
</template>

<script>
  export default {
    name: 'buttonBlock',

    data: () => ({
      
    }),
  };
</script>

<style scoped>
.theme--light.v-toolbar.v-sheet {
    background-color: #f46036;
}
.theme--light.v-sheet {
    background-color: #FFFFFF;
    border-color: #FFFFFF;
    color: rgb(255 255 255);
}
.theme--light.v-btn {
    color: rgb(255 255 255);
}
.v-btn:not(.v-btn--round).v-size--default[data-v-dfdda5ca] {
    padding: 23px 15px;
    font-size: 15px;
}
.buttonBlock {
    margin-left: 339px;
    margin-right: 359px;
    padding: 12px;
}
h2.text-center {
    font-size: 46px;
    margin-top: -9px;
    margin-left: -24px;
    font-weight: inherit;
}

</style>
