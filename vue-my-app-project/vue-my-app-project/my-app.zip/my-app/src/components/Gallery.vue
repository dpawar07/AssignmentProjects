<template>
  <v-container>
    <div class="block galleryBlock"><br>
    <h2 class="text-center">Gallery</h2><br>
        <v-row>
            <v-col
            v-for="n in 9"
            :key="n"
            class="d-flex child-flex"
            cols="4"
            >
            <v-card flat title class="d-flex">
            <v-img
                :src="`https://picsum.photos/500/300?image=${n * 5 + 10}`"
                :lazy-src="`https://picsum.photos/10/6?image=${n * 5 + 10}`"
                aspect-ratio="1"
                class="grey lighten-2"
            >
                <template v-slot:placeholder>
                <v-row
                    class="fill-height ma-0"
                    align="center"
                    justify="center"
                >
                    <v-progress-circular
                    indeterminate
                    color="grey lighten-5"
                    ></v-progress-circular>
                </v-row>
                </template>
            </v-img>
            </v-card>
            </v-col>
        </v-row><br><br><br>
    </div>
  </v-container>  
</template>

<script>
  export default {
    name: 'Gallery',

    data: () => ({
      
    }),
  };
</script>

<style scoped>
.theme--light.v-toolbar.v-sheet {
    background-color: #f46036;
}
.theme--light.v-sheet {
    background-color: #FFFFFF;
    border-color: #FFFFFF;
    color: rgb(255 255 255);
}
.theme--light.v-btn {
    color: rgb(255 255 255);
}
.v-btn:not(.v-btn--round).v-size--default {
    padding: 14px 12px;
    font-size: 15px;
}

</style>
