<template>
    <div class="caroselBlock">
        <v-carousel hide-delimiters cycle>
            <v-carousel-item
            v-for="(item,i) in items"
            :key="i"
            :src="item.src"
            reverse-transition="fade-transition"
            transition="fade-transition"
            ></v-carousel-item>
        </v-carousel>
    </div>
  
</template>

<script>
  export default {
    name: 'carousel',
    data () {
        return {
            items: [
            {
                src: 'https://cdn.vuetifyjs.com/images/carousel/squirrel.jpg',
            },
            {
                src: 'https://cdn.vuetifyjs.com/images/carousel/sky.jpg',
            },
            {
                src: 'https://cdn.vuetifyjs.com/images/carousel/bird.jpg',
            },
            {
                src: 'https://cdn.vuetifyjs.com/images/carousel/planet.jpg',
            },
        ],
      }
    },
  };
</script>

<style scoped>
.theme--light.v-toolbar.v-sheet {
    background-color: #f46036;
}
.theme--light.v-app-bar.v-toolbar.v-sheet {
    background-color: #f46036;
}

</style>
