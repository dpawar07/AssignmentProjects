<template>
  <v-container>
  <v-toolbar flat>
    <v-toolbar-title>DevMeetUp</v-toolbar-title>

    <v-spacer></v-spacer>
    <v-toolbar-items>
    <v-btn text>
      VIEW MEETUPS
    </v-btn>

    <v-btn text>
      ORGANIZE MEETUP
    </v-btn>

    <v-btn text>
      PROFILE
    </v-btn>

    <v-btn text>
      LOGOUT
    </v-btn>
    </v-toolbar-items>
  </v-toolbar>
  </v-container>
</template>

<script>
  export default {
    name: 'Header',

    data: () => ({
     
    }),
  }
</script>

<style scoped>
.theme--light.v-toolbar.v-sheet {
    background-color: #f46036;
}
.theme--light.v-sheet {
    background-color: #FFFFFF;
    border-color: #FFFFFF;
    color: rgb(255 255 255);
}
.theme--light.v-btn {
    color: rgb(255 255 255);
}
.v-btn:not(.v-btn--round).v-size--default {
    padding: 14px 12px;
    font-size: 15px;
}

</style>
