<template>
  <v-app>
    <v-app-bar
      app
      flat
    >
      <Header/>
    </v-app-bar>

    <v-main>
      <buttonBlock />
      <carousel />
      <Gallery />
    </v-main>

    <v-footer>
      <Footer />
    </v-footer>
  </v-app>
</template>

<script>
import Header from './components/Header';
import buttonBlock from './components/buttonBlock';
import carousel from './components/carousel';
import Gallery from './components/Gallery';
import Footer from './components/Footer';

export default {
  name: 'App',

  components: {
    Header,
    buttonBlock,
    carousel,
    Gallery,
    Footer
  },

  data: () => ({
    //
  }),
};
</script>

<style lang="scss">
header.v-sheet.theme--light.v-toolbar.v-toolbar--flat.v-app-bar.v-app-bar--fixed {
    background-color: #f46036;
}

.theme--light.v-footer {
    background-color: #1e1e1e;
    color: rgba(0, 0, 0, 0.87);
}
</style>
