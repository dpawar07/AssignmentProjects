<template>
  <div class="p-10">
    <div>
      <input type="text" class="search-class" placeholder="Search records" @input="onSearch" />
    </div>
    <table>
      <thead style="background-color: lightgoldenrodyellow; color: firebrick;">
        <tr>
          <th 
            v-for="(column, index) in columns"
            v-bind:key="index"
            v-on:click="sortRecords(index)"
          >
            {{column}}
          </th>
          
        </tr>
      </thead>
      <tbody>
        <tr 
          v-for="(row, index) in rows"
            v-bind:key="index"
        >
          <td 
            v-for="(rowItem, itemIndex) in row"
            v-bind:key="itemIndex"
          >
          {{rowItem}}
          </td>
        </tr>
      </tbody>
    </table>
  </div>
 
</template>

<script>

const performSearch = (rows, term) => {
  const results = rows.filter(
    row => row.join(" ").toLowerCase().includes(term.toLowerCase())
  )
  
  return results;
}
export default {
  name: 'Table',
  data () {
    return {
      term: '',
      rawRows: [
        [
          "1","Sanjana","23","software Developer","1995","sanjana@gmail.com","Bidar","9876789654"
        ],
        [
          "2","John","25","Mechanical Engineer","1991","john12@gmail.com","Latur","6575467896"
        ],
        [
          "3","Pooja","26","UI/UX Designer","1997","poojas12@gmail.com","Bidar","9878909876"
        ],
        [
          "4","Raksha","27","Saleswomen","1993","raksha@gmail.com","Raichur","9878907685"
        ],
        [
          "5","Mansi","22","software Developer","1997","mansipawar@gmail.com","Latur","6789567456"
        ],
        [
          "6","Aditya","23","UI/UX Developer","1992","adityamoe@gmail.com","Bengalore","9067856745"
        ],
        [
          "7","Sidharth","23","Salesmen","1997","sidharth3@gmail.com","Bidar","6754321678"
        ]
      ],
      rows: [],
      columns: [
        'SL NO',
        'Name',
        'Age',
        'Profession',
        'Year of birth',
        'Email',
        'Address',
        'Mobile Number'
      ],
      sortIndex: null,
      sortDirection: null,
    }
  },
 methods: {
   sortRecords (index) {
     if (this.sortIndex === index) {
       switch (this.sortDirection) {
         case null:
          this.sortDirection = 'asc';
          break;
         case 'asc':
          this.sortDirection = 'desc';
          break;
         case 'desc':
          this.sortDirection = null;
          break;
       }
     }else {
       this.sortDirection = 'asc'
     }

     this.sortIndex = index;

     console.log(this.sortDirection)

     if (!this.sortDirection) {
       this.rows = performSearch(this.rawRows, this.term);
       return;
     }

     this.rows = this.rows.sort(
       (rowA, rowB) => {
         if (this.sortDirection === 'desc') {
           return rowB[index].localeCompare(rowA[index]);
         }

         return rowA[index].localeCompare(rowB[index]);
       }
     )
   },
   onSearch (e) {
    this.term = e.target.value;

    this.rows = performSearch(this.rawRows, this.term);
   },
 },
 mounted () {
   this.rows = [...this.rawRows];
 }
}
</script>

<style>
  table, td, th {
  border: 1px solid dimgray;
  padding: 14px;
}

table {
  width: 63%;
  border-collapse: collapse;
  text-align: center;
  margin-top: 19px;
  margin-left: 303px;
}

input.search-class {
    margin-left: 303px;
    margin-top: 57px;
    padding: 11px;
    width: 255px;
    border: 1px solid dimgray;
}
</style>


